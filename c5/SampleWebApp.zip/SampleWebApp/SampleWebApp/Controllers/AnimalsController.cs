﻿using Microsoft.AspNetCore.Mvc;
using SampleWebApp.Services;
using System.Threading.Tasks;

namespace SampleWebApp
{
    [Route("api/animals")]
    [ApiController]
    public class AnimalsController : ControllerBase
    {

        private readonly IDatabaseService _dbService;
        private readonly IDatabaseService2 _dbService2;

        public AnimalsController(IDatabaseService dbService, IDatabaseService2 dbService2)
        {
            _dbService = dbService;
            _dbService2 = dbService2;
        }

        [HttpGet]
        public IActionResult GetAnimals()
        {
            return Ok(_dbService.GetAnimals());
        }

        [HttpGet("proc")]
        public async Task<IActionResult> GetAnimalsByProc()
        {
            return Ok(await _dbService2.GetAnimalsByStoredProcedureAsync());
        }

        [HttpPut]
        public async Task<IActionResult> UpdateAnimals()
        {
            return Ok(await _dbService2.ChangeAnimalAsync());
        }

        [HttpGet("async")]
        public async Task<IActionResult> GetAnimals2()
        {
            return Ok(await _dbService2.GetAnimalsAsync());
        }

    }
}
