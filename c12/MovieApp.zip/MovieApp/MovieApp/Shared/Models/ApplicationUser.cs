﻿using Microsoft.AspNetCore.Identity;

namespace MovieApp.Shared.Models
{
    public class ApplicationUser : IdentityUser
    {

    }
}
