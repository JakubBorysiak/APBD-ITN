﻿export function displayAlert(message) {
    return alert(message);
}